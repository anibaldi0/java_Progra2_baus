
package parcial1progra2baus;

public class CruceroEstelar extends Nave {
    private int cantidadPasajeros;

    public CruceroEstelar(String nombre, int capacidadTripulacion, int anoLanzamiento, int cantidadPasajeros) {
        super(nombre, capacidadTripulacion, anoLanzamiento);
        if (cantidadPasajeros <= 0) {
            throw new IllegalArgumentException("Debe haber algun pasajero a bordo para zarpar.");
        }
        this.cantidadPasajeros = cantidadPasajeros;
    }

    public int getCantidadPasajeros() {
        return cantidadPasajeros;
    }

    @Override
    public String mostrarInfo() {
        return mostrarInfoBase() + ", Cantidad de pasajeros a bordo: " + Color.AZUL + cantidadPasajeros + Color.RESET;
    }
}

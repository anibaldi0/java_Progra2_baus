package parcial1progra2baus;

public class Carguero extends Nave implements Exploracion {
    private int capacidadCarga;

    public Carguero(String nombre, int capacidadTripulacion, int anoLanzamiento, int capacidadCarga) {
        super(nombre, capacidadTripulacion, anoLanzamiento);
        if (capacidadCarga < 100 || capacidadCarga > 500) {
            throw new IllegalArgumentException("La capacidad de carga debe estar entre 100 y 500 toneladas.");
        }
        this.capacidadCarga = capacidadCarga;
    }

    @Override
    public String mostrarInfo() {
        return mostrarInfoBase() + ", Capacidad de carga: " + Color.AZUL +capacidadCarga + Color.RESET +" toneladas.";
    }

    @Override
    public void explorar() {
    }
}

package parcial1progra2baus;

public class NaveExploracion extends Nave implements Exploracion {
    private TipoMision tipoMision;

    public NaveExploracion(String nombre, int capacidadTripulacion, int anoLanzamiento, TipoMision tipoMision) {
        super(nombre, capacidadTripulacion, anoLanzamiento);
        this.tipoMision = tipoMision;
    }

    @Override
    public String mostrarInfo() {
        return mostrarInfoBase() + ", Tipo de mision: " + Color.AZUL + tipoMision + Color.RESET;
    }

    @Override
    public void explorar() {
        
    }
}

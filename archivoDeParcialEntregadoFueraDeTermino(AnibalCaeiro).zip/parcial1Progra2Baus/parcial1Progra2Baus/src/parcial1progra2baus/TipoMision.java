
package parcial1progra2baus;

public enum TipoMision {
    CARTOGRAFIA,
    INVESTIGACION,
    CONTACTO;
}

package parcial1progra2baus;

public abstract class Nave{
    private String nombre;
    private int capacidadTripulacion;
    private int anoLanzamiento;

    public Nave(String nombre, int capacidadTripulacion, int anoLanzamiento) {
        this.nombre = nombre;
        this.capacidadTripulacion = capacidadTripulacion;
        this.anoLanzamiento = anoLanzamiento;
    }

    public String getNombre() {
        return nombre;
    }

    public int getCapacidadTripulacion() {
        return capacidadTripulacion;
    }

    public int getAnoLanzamiento() {
        return anoLanzamiento;
    }
    
    protected String mostrarInfoBase() {
        return "Nombre: " + Color.VERDE + getNombre() + Color.RESET +
               ", Capacidad de tripulacion: " + Color.AZUL + getCapacidadTripulacion() + Color.RESET + 
               ", Ano de Lanzamiento: " + Color.AZUL + getAnoLanzamiento() + Color.RESET;
    }

    public abstract String mostrarInfo();
}

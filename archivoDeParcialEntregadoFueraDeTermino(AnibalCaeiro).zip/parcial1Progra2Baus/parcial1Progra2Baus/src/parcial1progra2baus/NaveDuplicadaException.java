
package parcial1progra2baus;

public class NaveDuplicadaException extends Exception {
    public NaveDuplicadaException(String mensaje) {
        super(mensaje);
    }
}

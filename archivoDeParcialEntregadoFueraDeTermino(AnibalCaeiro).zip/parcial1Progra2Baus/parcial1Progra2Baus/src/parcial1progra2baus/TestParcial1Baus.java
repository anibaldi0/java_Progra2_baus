package parcial1progra2baus;

public class TestParcial1Baus {

    public static void main(String[] args) {
        BaseEspacial base = new BaseEspacial("Estación Espacial Internacional");

        try {
            Nave naveExploracion1 = new NaveExploracion("Explorer_ya", 5, 2021, TipoMision.CARTOGRAFIA);
            Nave carguero1 = new Carguero("Pampero_Cargo", 8, 2022, 200);
            Nave cruceroEstelar1 = new CruceroEstelar("Galactica_Astronave_de_Combate", 15, 2020, 150);

            base.agregarNave(naveExploracion1);
            base.agregarNave(carguero1);
            base.agregarNave(cruceroEstelar1);

            Nave naveDuplicada = new NaveExploracion("Explorer_ya", 5, 2021, TipoMision.CONTACTO);
            base.agregarNave(naveDuplicada);

        } catch (NaveDuplicadaException e) {
            System.out.println(Color.ROJO + "Error de duplicacion: " + Color.RESET + e.getMessage());
        } catch (IllegalArgumentException e) {
            System.out.println(Color.ROJO + "Error al crear una nave: " + Color.RESET + e.getMessage());
        }

        base.mostrarNaves();
        base.iniciarExploracion();
    }
}

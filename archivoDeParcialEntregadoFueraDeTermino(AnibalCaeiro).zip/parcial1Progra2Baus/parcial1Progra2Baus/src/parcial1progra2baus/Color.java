
package parcial1progra2baus;

public class Color {
    public static final String ROJO = "\u001B[31m";
    public static final String VERDE = "\u001B[32;2m";
    public static final String AZUL = "\u001B[34m";
    public static final String NEGRO = "\u001B[30m";
    public static final String AMARILLO = "\u001B[33m";
    public static final String RESET = "\u001B[0m";

    public static String colorTexto(String texto, String color) {
        return color + texto + RESET;
    }
}


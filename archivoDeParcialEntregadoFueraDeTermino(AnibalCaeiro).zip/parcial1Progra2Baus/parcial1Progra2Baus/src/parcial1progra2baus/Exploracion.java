
package parcial1progra2baus;

public interface Exploracion {
    void explorar();
}

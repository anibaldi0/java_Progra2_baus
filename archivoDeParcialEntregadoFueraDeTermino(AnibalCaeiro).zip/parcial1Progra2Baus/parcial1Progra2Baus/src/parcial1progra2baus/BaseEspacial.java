
package parcial1progra2baus;

import java.util.ArrayList;
import java.util.List;

public class BaseEspacial {
    private String nombre;
    private List<Nave> naves;

    public BaseEspacial(String nombre) {
        this.nombre = nombre;
        this.naves = new ArrayList<>();
    }

    public void agregarNave(Nave nave) throws NaveDuplicadaException {
        for (Nave n : naves) {
            if (n.getNombre().equals(nave.getNombre())) {
                throw new NaveDuplicadaException("La nave con nombre " + nave.getNombre() + " y ano " + nave.getAnoLanzamiento() + " ya esta en la base.");
            }
        }
        naves.add(nave);
    }

    public void mostrarNaves() {
        for (Nave nave : naves) {
            System.out.println(nave.mostrarInfo());
        }
    }

    public void iniciarExploracion() {
        for (Nave nave : naves) {
            if (nave instanceof Exploracion) {
                ((Exploracion) nave).explorar();
            } else {
                System.out.println("El crucero estelar " + Color.ROJO + nave.getNombre() + Color.RESET + " no esta capacitado para exploracion.");
            }
        }
    }
}
